package org.example.act_8_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Act81ApplicationTests {

	@Test
	void contextLoads() {
	}

}
